#!/bin/bash
sudo apt update
sudo apt install apache2
